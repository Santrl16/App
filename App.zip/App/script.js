let timer;
let seconds = 0;
let isRunning = false;

const display = document.getElementById('timer');
const startButton = document.getElementById('start');
const stopButton = document.getElementById('stop');
const resetButton = document.getElementById('reset');

// Función para actualizar el temporizador
function updateTime() {
    seconds++;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    display.textContent = `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// Iniciar el temporizador
startButton.addEventListener('click', () => {
    if (!isRunning) {
        timer = setInterval(updateTime, 1000);
        isRunning = true;
    }
});

// Detener el temporizador
stopButton.addEventListener('click', () => {
    clearInterval(timer);
    isRunning = false;
});

// Reiniciar el temporizador
resetButton.addEventListener('click', () => {
    clearInterval(timer);
    isRunning = false;
    seconds = 0;
    display.textContent = '00:00';
});
